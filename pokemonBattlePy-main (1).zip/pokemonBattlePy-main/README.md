# pokemonBattlePy
A pokemon Battle game made in Python just for fun, using Pygame as a main library.

## Libraries I use:
1. Pygame
2. PokeApi
