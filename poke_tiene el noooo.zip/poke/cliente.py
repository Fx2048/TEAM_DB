import socket

# Cliente
def cliente():
    s = socket.socket()
    s.connect(('localhost', 12345))
    while True:
        message = input("Escribe un mensaje: ")
        s.sendall(message.encode())
        data = s.recv(1024)
        print(f"Echo: {data.decode()}")

# Ejecutar el servidor y el cliente en diferentes terminales
cliente()