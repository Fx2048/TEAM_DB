import pygame
import sys
import csv
import os
from datetime import datetime

# Inicializar Pygame
pygame.init()

# Configuraciones de la ventana
WIDTH, HEIGHT = 500, 500
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Juego con Login")

# Fuentes
font = pygame.font.Font(None, 36)

# Variables para el Login
username = ""
is_logged_in = False
input_active = False  # Para saber si el campo de entrada está activo

# Nombre de archivos
filename = 'usuarios.csv'
log_filename = 'registro_cambios.csv'  # Archivo para el registro de cambios

# Función para crear el archivo CSV si no existe
def create_user_file(filename):
    if not os.path.exists(filename):
        with open(filename, mode='w', newline='') as file:
            writer = csv.writer(file)
            writer.writerow(["usuario"])  # Cabecera opcional

# Función para crear el archivo de registro de cambios si no existe
def create_log_file(log_filename):
    if not os.path.exists(log_filename):
        with open(log_filename, mode='w', newline='') as file:
            writer = csv.writer(file)
            writer.writerow(["fecha", "usuario", "accion"])  # Cabecera

# Función para leer usuarios del CSV
def read_users_from_csv(filename):
    users = []
    with open(filename, mode='r') as file:
        reader = csv.reader(file)
        try:
            next(reader)  # Intentar saltar la cabecera si existe
        except StopIteration:
            return users  # Retorna la lista vacía si no hay filas

        for row in reader:
            users.append(row[0])
    return users


# Función para guardar un nuevo usuario en el CSV
def save_user_to_csv(username, filename):
    with open(filename, mode='a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([username])  # Escribir el nuevo usuario

# Función para registrar cambios en el log
def log_change(username, action):
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')  # Obtener la fecha y hora actual
    with open(log_filename, mode='a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([timestamp, username, action])  # Registrar el cambio

# Función para mostrar la pantalla de login
def login_screen():
    global username, is_logged_in, input_active

    create_user_file(filename)  # Crear el archivo si no existe
    valid_users = read_users_from_csv(filename)  # Leer usuarios válidos
    create_log_file(log_filename)  # Crear el archivo de log si no existe

    while not is_logged_in:
        screen.fill((255, 255, 255))  # Fondo blanco

        # Mostrar texto
        login_text = font.render("Login / Registro", True, (0, 0, 0))
        screen.blit(login_text, (WIDTH // 2 - 100, 50))

        # Mostrar etiqueta "Usuario:"
        user_label = font.render("Usuario:", True, (0, 0, 0))
        screen.blit(user_label, (WIDTH // 2 - 100, 150))  # Posición de la etiqueta

        # Rectángulo para el campo de entrada
        input_rect = pygame.Rect(WIDTH // 2 - 100, 200, 200, 40)
        pygame.draw.rect(screen, (0, 0, 0), input_rect, 2)  # Contorno negro del rectángulo

        # Mostrar texto del usuario en el campo de entrada
        user_text = font.render(username, True, (0, 0, 0))
        screen.blit(user_text, (input_rect.x + 5, input_rect.y + 5))  # Texto en el campo

        # Botón "Comienza"
        button_text = font.render("Empezar", True, (255, 255, 255))
        button_rect = pygame.Rect(WIDTH // 2 - 60, 300, 120, 50)
        pygame.draw.rect(screen, (0, 0, 255), button_rect)  # Botón azul
        screen.blit(button_text, (button_rect.x + 6, button_rect.y + 10))  # Texto en el botón

        pygame.display.flip()

        # Capturar eventos
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_RETURN:  # Presionar Enter
                    if username in valid_users:  # Validar credenciales
                        is_logged_in = True
                        log_change(username, "Inicio de sesión")  # Log de inicio de sesión
                    elif username:  # Si el usuario no existe, registrarlo
                        save_user_to_csv(username, filename)
                        log_change(username, "Registro")  # Log de registro
                        valid_users.append(username)  # Agregar a la lista local
                        is_logged_in = True  # Iniciar sesión después del registro
                elif event.key == pygame.K_BACKSPACE:  # Borrar el último carácter
                    username = username[:-1]

                # Agregar caracteres al nombre de usuario si el campo está activo
                if input_active and event.unicode.isprintable() and len(username) < 20:
                    username += event.unicode

            if event.type == pygame.MOUSEBUTTONDOWN:  # Manejar clics del mouse
                if event.button == 1:  # Clic izquierdo
                    if input_rect.collidepoint(event.pos):  # Si el clic es en el campo de entrada
                        input_active = True  # Activar el campo de entrada
                    else:
                        input_active = False  # Desactivar el campo si se hace clic fuera

                    if button_rect.collidepoint(event.pos):  # Si el botón es clickeado
                        if username in valid_users:  # Validar credenciales
                            is_logged_in = True
                            log_change(username, "Inicio de sesión")  # Log de inicio de sesión
                        elif username:  # Si el usuario no existe, registrarlo
                            save_user_to_csv(username, filename)
                            log_change(username, "Registro")  # Log de registro
                            valid_users.append(username)  # Agregar a la lista local
                            is_logged_in = True  # Iniciar sesión después del registro

# Función para la pantalla principal del juego
def main_game():
    # Cargar la imagen de fondo
    background_image = pygame.image.load('foto.jpg')  # Cambia 'fondo.jpg' al nombre de tu imagen
    background_image = pygame.transform.scale(background_image, (WIDTH, HEIGHT))  # Escalar la imagen al tamaño de la ventana

    while True:
        # Dibujar la imagen de fondo
        screen.blit(background_image, (0, 0))  # Dibujar la imagen de fondo
        pygame.display.flip()  # Actualizar la pantalla

# Iniciar la pantalla de login
login_screen()
main_game()
