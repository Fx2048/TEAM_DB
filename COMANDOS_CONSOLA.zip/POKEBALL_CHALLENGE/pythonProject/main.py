import pygame
import random

pygame.init()

# Colores
white = (255, 255, 255)
black = (0, 0, 0)
red = (213, 50, 80)
blue = (50, 153, 213)
green = (0, 255, 0)

# Dimensiones
dis_width = 920
dis_height = 600
info_width =150 # Ancho de la pantalla lateral para las vidas

# Configuración de pantalla
dis = pygame.display.set_mode((dis_width + info_width, dis_height))
pygame.display.set_caption("Ventana 1 - Snake Game con Botones")
clock = pygame.time.Clock()

# Cargamos las imágenes de la serpiente, comida y corazones
snake_img = pygame.image.load('imagenes/pokeball.png')
pokemon_images = ['imagenes/pikachu.png', 'imagenes/charmander.png', 'imagenes/bulbasaur.png']
heart_img = pygame.image.load('imagenes/heart.png')

# Redimensionamos las imágenes
snake_img = pygame.transform.scale(snake_img, (30, 30))
heart_img = pygame.transform.scale(heart_img, (30, 30))

# Fuentes y texto
font_style = pygame.font.SysFont("bahnschrift", 25)

# Función para dibujar la serpiente
def our_snake(snake_list):
    for x in snake_list:
        dis.blit(snake_img, (x[0], x[1]))

# Función para mostrar las vidas (corazones)
def show_lives(lives):
    for i in range(lives):
        dis.blit(heart_img, (dis_width + 20, 50 + i * 40))

# Función para mostrar botones y detectar clic
def draw_button(text, x, y, width, height, color, action=None):
    pygame.draw.rect(dis, color, [x, y, width, height])
    msg = font_style.render(text, True, black)
    dis.blit(msg, [x + (width / 4), y + (height / 4)])

    # Detectar si el botón es presionado
    mouse = pygame.mouse.get_pos()
    click = pygame.mouse.get_pressed()
    if x < mouse[0] < x + width and y < mouse[1] < y + height:
        if click[0] == 1 and action is not None:
            action()

# Acciones de los botones
def move_up():
    global x1_change, y1_change
    y1_change = -20
    x1_change = 0

def move_down():
    global x1_change, y1_change
    y1_change = 20
    x1_change = 0

def move_left():
    global x1_change, y1_change
    x1_change = -20
    y1_change = 0

def move_right():
    global x1_change, y1_change
    x1_change = 20
    y1_change = 0

# Bucle principal del juego
def gameLoop(snake_speed):
    global x1_change, y1_change
    game_over = False
    game_close = False

    x1 = dis_width / 2
    y1 = dis_height / 2
    x1_change = 0
    y1_change = 0
    snake_list = []
    length_of_snake = 1

    lives = 3

    food_img = pygame.image.load(random.choice(pokemon_images))
    food_img = pygame.transform.scale(food_img, (30, 30))
    foodx = round(random.randrange(0, dis_width - 30) / 10.0) * 10.0
    foody = round(random.randrange(0, dis_height - 30) / 10.0) * 10.0

    start_ticks = pygame.time.get_ticks()

    while not game_over:

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                game_over = True

        if x1 >= dis_width or x1 < 0 or y1 >= dis_height or y1 < 0:
            lives -= 1
            if lives == 0:
                game_close = True
            else:
                x1, y1 = dis_width / 2, dis_height / 2

        x1 += x1_change
        y1 += y1_change
        dis.fill(blue)

        dis.blit(food_img, (foodx, foody))

        snake_head = [x1, y1]
        snake_list.append(snake_head)
        if len(snake_list) > length_of_snake:
            del snake_list[0]

        for x in snake_list[:-1]:
            if x == snake_head:
                lives -= 1
                if lives == 0:
                    game_close = True

        if abs(x1 - foodx) < 30 and abs(y1 - foody) < 30:
            foodx = round(random.randrange(0, dis_width - 30) / 10.0) * 10.0
            foody = round(random.randrange(0, dis_height - 30) / 10.0) * 10.0
            length_of_snake += 1
            snake_speed += 1
            food_img = pygame.image.load(random.choice(pokemon_images))
            food_img = pygame.transform.scale(food_img, (30, 30))

        our_snake(snake_list)

        seconds = (pygame.time.get_ticks() - start_ticks) / 1000
        time_text = font_style.render(f"Time: {seconds:.2f}", True, black)
        dis.blit(time_text, [0, 0])

        pygame.draw.rect(dis, white, [dis_width, 0, info_width, dis_height])
        show_lives(lives)

        # Dibujar botones en forma de cruz
        draw_button("A", dis_width + 50, 250, 60, 30, green, move_up)  # Arriba
        draw_button("B", dis_width + 50, 450, 60, 30, green, move_down)  # Abajo
        draw_button("I", dis_width + 10, 350, 60, 30, green, move_left)  # Izquierda
        draw_button("D", dis_width + 100, 350, 60, 30, green, move_right)  # Derecha

        pygame.display.update()
        clock.tick(snake_speed)

    pygame.quit()
    quit()

# Iniciamos el juego con una velocidad inicial de 10
gameLoop(snake_speed=10)
